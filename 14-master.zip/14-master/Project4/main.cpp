#include <iostream>
#include <Windows.h>

// Задание 1

bool Visokosny(int god)
{
    if (god % 400 == 0 || (god % 4 == 0 && god % 100 != 0))
    {
        return true;
    }
    else
    {
        return false;
    }
}

int DniVMesyace(int mesyac, int god)
{
    int dni[12]{ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

    if (mesyac == 2 && Visokosny(god))
    {
        return 29;
    }

    return dni[mesyac - 1];
}

int VseDni(int den, int mesyac, int god)
{
    int summa = 0;

    for (int i = 1; i < god; i++)
    {
        if (Visokosny(i))
        {
            summa += 366;
        }
        else
        {
            summa += 365;
        }
    }

    for (int i = 1; i < mesyac; i++)
    {
        summa += DniVMesyace(i, god);
    }

    summa += den;

    return summa;
}

int RaznicaDat(int den1, int mesyac1, int god1,
    int den2, int mesyac2, int god2)
{
    int data1 = VseDni(den1, mesyac1, god1);
    int data2 = VseDni(den2, mesyac2, god2);

    if (data1 > data2)
    {
        return data1 - data2;
    }
    else
    {
        return data2 - data1;
    }
}


// Задание 2

double Srednee(int arr[], int size)
{
    int summa = 0;

    for (int i = 0; i < size; i++)
    {
        summa += arr[i];
    }

    return summa / (size * 1.0);
}


// Задание 3

void Podschet(int arr[], int size)
{
    int polozh = 0;
    int otric = 0;
    int nuli = 0;

    for (int i = 0; i < size; i++)
    {
        if (arr[i] > 0)
        {
            polozh++;
        }
        else if (arr[i] < 0)
        {
            otric++;
        }
        else
        {
            nuli++;
        }
    }

    std::cout << "Положительных: " << polozh << "\n";
    std::cout << "Отрицательных: " << otric << "\n";
    std::cout << "Нулевых: " << nuli << "\n";
}


int main()
{
    SetConsoleCP(CP_UTF8);
    SetConsoleOutputCP(CP_UTF8);


    // Задание 1

    int den1 = 0, mesyac1 = 0, god1 = 0;
    int den2 = 0, mesyac2 = 0, god2 = 0;

    std::cout << "Задание 1\n\n";

    std::cout << "Введите первую дату (день месяц год): ";
    std::cin >> den1 >> mesyac1 >> god1;

    std::cout << "Введите вторую дату (день месяц год): ";
    std::cin >> den2 >> mesyac2 >> god2;

    if (god1 < 1 || god2 < 1 ||
        mesyac1 < 1 || mesyac1 > 12 ||
        mesyac2 < 1 || mesyac2 > 12)
    {
        std::cout << "Неверная дата!\n";
    }
    else if (den1 < 1 || den2 < 1 ||
        den1 > DniVMesyace(mesyac1, god1) ||
        den2 > DniVMesyace(mesyac2, god2))
    {
        std::cout << "Неверная дата!\n";
    }
    else
    {
        std::cout << "Разница в днях: "
            << RaznicaDat(den1, mesyac1, god1,
                den2, mesyac2, god2) << "\n";
    }


    // Задание 2

    const int size = 10;
    int arr[size]{};

    std::cout << "\nЗадание 2\n\n";
    std::cout << "Введите 10 чисел:\n";

    for (int i = 0; i < size; i++)
    {
        std::cin >> arr[i];
    }

    std::cout << "Среднее арифметическое: "
        << Srednee(arr, size) << "\n";


    // Задание 3

    std::cout << "\nЗадание 3\n\n";

    Podschet(arr, size);

    return 0;
}